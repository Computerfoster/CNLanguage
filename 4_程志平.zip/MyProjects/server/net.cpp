#include "function.h"

int Net()
{
	WORD sockVersion = MAKEWORD(2, 2);//��ʼ��WSA
	WSADATA wsaData;
	if (WSAStartup(sockVersion, &wsaData) != 0)
	{
		return 0;
	}
	SOCKET server = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);//�����׽���
	if (server == INVALID_SOCKET)
	{
		printf("socket error!");
		return 0;
	}
	//��ͨ�Ŷ˿�
	sockaddr_in sin;
	sin.sin_family = AF_INET;
	sin.sin_port = htons(8088);
	sin.sin_addr.S_un.S_addr = INADDR_ANY;
	if (bind(server, (LPSOCKADDR)&sin, sizeof(sin)) == SOCKET_ERROR)
	{
		printf("bind error!");
	}
	//��ʼ����
	if (listen(server, 5) == SOCKET_ERROR)
	{
		printf("listen error!");
		return 0;
	}
	printf("�ȴ���Ϣ����!\n");
	//�ȴ���������
	SOCKET s_client;
	sockaddr_in destaddr;
	int nAddrlen = sizeof(destaddr);
	char *sendData;
	char *revData;

	while (1)
	{
		s_client = accept(server, (SOCKADDR *)&destaddr, &nAddrlen);
		if (s_client == INVALID_SOCKET)
		{
			printf("accpet error!\n");
			continue;
		}
		sendData = (char *)malloc(MAX_DATA_LEN);
		memset(sendData, '0', MAX_DATA_LEN);
		strcpy(sendData, "0(���Է������Ļ�ӭ��Ϣ)��ӭʹ�û���Socket��ͨѶ¼��\n��������Ҫִ�еĹ�����ţ�\n");
		send(s_client, sendData, strlen(sendData), 0);
		printf("���յ�һ������:%s\n", inet_ntoa(destaddr.sin_addr));
		revData = (char *)malloc(MAX_DATA_LEN);
		while (1)
		{
			memset(revData, '0', MAX_DATA_LEN);
			int ret = recv(s_client, revData, MAX_DATA_LEN, 0);
			revData[ret] = 0x00;
			if (ret > 0 && atoi(revData) > 0 && isdigit(revData[0]))
			{
				revData[ret] = 0x00;
				printf("�ͻ��������ָ��Ϊ%s\n", revData);
				if (atoi(&revData[0]) == 1)
				{
					memset(sendData, '0', MAX_DATA_LEN);
					strcpy(sendData, "1\n");
					send(s_client, sendData, strlen(sendData), 0);
					int retn = AllAddress(&s_client, &Send);
					if (retn == NO_ADDRESSEXIST)
					{
						memset(sendData, '0', MAX_DATA_LEN);
						Contacts tmp1 = { "",0,0,"","",0 };
						send(s_client, (char *)&tmp1, sizeof(tmp1), 0);
						strcpy(sendData, "0�����û��ͨѶ¼!\n");
						send(s_client, sendData, strlen(sendData), 0);
					}
					if (retn == OK)
					{
						memset(sendData, '0', MAX_DATA_LEN);
						Contacts tmp1 = { "",0,0,"","",0 };
						send(s_client, (char *)&tmp1, sizeof(tmp1), 0);
						memset(sendData, '0', MAX_DATA_LEN);
						strcpy(sendData, "0ͨѶ¼�������!\n");
						send(s_client, sendData, strlen(sendData), 0);
					}
				}
				if (atoi(&revData[0]) == 2)
				{
					Contacts cont;
					memset(sendData, '0', MAX_DATA_LEN);
					strcpy(sendData, "2��¼����Ϣ:\n");
					send(s_client, sendData, strlen(sendData), 0);
					memset(revData, '0', MAX_DATA_LEN);
					while ((ret = recv(s_client, (char *)&cont, MAX_DATA_LEN, 0))<0);
					if (ret > 0)
					{
						strcpy(cont.ip, inet_ntoa(destaddr.sin_addr));
						Insert(cont);
					}
				}
				if (atoi(&revData[0]) == 3)
				{
					memset(sendData, '0', MAX_DATA_LEN);
					strcpy(sendData, "0(�����ȷ��)�ͻ��������ر�ͨ��!\n");
					printf("%s", &sendData[1]);
					send(s_client, sendData, strlen(sendData), 0);
					break;
				}
				//��Ϣȷ�Ͻ���
				char *tmp;
				tmp = (char*)malloc(MAX_DATA_LEN);
				recv(s_client, tmp, MAX_DATA_LEN, 0);
				free(tmp);
				//###end###
				continue;
			}
			else if (ret>0)
			{
				revData[ret] = 0x00;
				printf("%s\n", revData);
				memset(sendData, '0', MAX_DATA_LEN);
				strcpy(sendData, "0���!\n");
				send(s_client, sendData, strlen(sendData), 0);
			}
		}
		closesocket(s_client);
	}
	closesocket(server);
	if (!revData)
		free(revData);
	if (sendData)
		free(sendData);
	WSACleanup();
	return 0;
}
