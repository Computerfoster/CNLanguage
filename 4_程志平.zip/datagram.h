#pragma once

typedef struct Contacts
{
	char name[20];
	int age;
	bool sex;
	char unit[30];
	char tel[15];
	char ip[20];
}Contacts;
