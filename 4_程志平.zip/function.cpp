#include"function.h"
#include "string.h"
#include "datagram.h"

Status AddInformation(SOCKET *server,Status SEND(SOCKET *server,Contacts cont))//������ϵ��
{
	int tmp;
	char name[20];
	int age;
	bool sex;
	char unit[30];
	char tel[15];
	char ip[20];
	printf("��������������,����,�Ա�(��:1;Ů:0),��λ,�绰(�Իس�����)\n");
	scanf("%s", name);
	scanf("%d", &age);
	scanf("%d", &tmp);
	if (tmp == 1)
		sex = 1;
	else
		sex = 0;
	scanf("%s", unit);
	scanf("%s", tel);
	strcpy(ip,"localhost");
	Contacts cont;
	memcpy(cont.name, &name, sizeof(name));
	cont.age = age;
	cont.sex = sex;
	memcpy(cont.unit, &unit, sizeof(unit));
	memcpy(cont.tel, &tel, sizeof(tel));
	memcpy(cont.ip, &ip, sizeof(ip));
	if (SEND == 0)
	{
		//#########������########
		printf("%s\t%d\t%s\t%s\t%s\t%s\n", cont.name, cont.age, cont.sex ? "��" : "Ů", cont.unit, cont.tel, cont.ip);
		//#######################
	}
	else
		SEND(server,cont);
	Insert(cont);
	printf("#########��Ϣ¼�����########\n");
	return OK;
}

Status AllAddress(SOCKET *client,Status SEND(SOCKET *client,Contacts))//������ϵ��
{
	FILE *filein = fopen("contacts.dat", "r");
	Contacts tmp1;
	if (!filein)
	{
		return NO_ADDRESSEXIST;
	}
	while (!feof(filein))
	{
		int ret = fread(&tmp1, sizeof(Contacts), 1, filein);
		if (ret>0)
		{
			if (SEND == 0)
			{
				//printf("%d\n", ret);
				printf("%s\t%d\t%d\t%s\t%s\t%s\n", tmp1.name, tmp1.age, tmp1.sex, tmp1.unit, tmp1.tel, tmp1.ip);
			}
			else
				SEND(client,tmp1);
		}
	}
	fclose(filein);
	return OK;
}

Status Del(char *name, SOCKET *client, Status SEND(SOCKET *client, Contacts))//ɾ����ϵ��
{

	Contacts tmp,tmp1;
	int ret;
	//����ͨѶ¼
	FILE *filein = fopen("contacts.dat", "rb");
	if (!filein)
		return NO_ADDRESSEXIST;
	FILE *fileout = fopen("contacts.dat.bak", "wb");
	while (!feof(filein))
	{
		if (fread(&tmp, sizeof(Contacts), 1, filein) > 0)
			fwrite(&tmp, sizeof(Contacts), 1, fileout);
	}
	fclose(filein);
	fclose(fileout);
	//######end######
	filein = fopen("contacts.dat.bak", "rb");
	if (!filein)
		return NO_ADDRESSEXIST;
	fileout = fopen("contacts.dat", "wb");
	while (!feof(filein))
	{
		ret = fread(&tmp1, sizeof(Contacts), 1, filein);
		if (ret>0)
		{
			if (SEND == 0 && !strcmp(tmp1.name, name))
			{
				printf("ɾ������ϢΪ:%s\t%d\t%d\t%s\t%s\t%s\n", tmp1.name, tmp1.age, tmp1.sex, tmp1.unit, tmp1.tel, tmp1.ip);
				continue;
			}
			else if((SEND != 0 && !strcmp(tmp1.name, name)))
			{ 
				Send(client, tmp1);
				continue;
			}
			fwrite(&tmp1, sizeof(Contacts), 1, fileout);
		}
	}
	fclose(filein);
	fclose(fileout);
	return OK;
}

Status Search(Contacts &cont, SOCKET *client, Status SEND(SOCKET *client, Contacts))//��̨���ݵĲ���
{
	Contacts tmp1;
	FILE *filein = fopen("contacts.dat","rb");
	if(!filein)
		return NO_ADDRESSEXIST;
	while(!feof(filein))
	{
		int ret = fread(&tmp1,sizeof(Contacts),1,filein);
		if (ret>0)
		{
			cont = tmp1;
			if (SEND == 0 && !strcmp(tmp1.name, cont.name))
			{
				printf("%s\t%d\t%d\t%s\t%s\t%s\n", tmp1.name, tmp1.age, tmp1.sex, tmp1.unit, tmp1.tel, tmp1.ip);
			}
			else if ((SEND != 0 && !strcmp(tmp1.name, cont.name)))
				Send(client, tmp1);
		}
	}
	struct Contacts tmp = {"0",0,true,"","",0};
	cont = tmp;
	fclose(filein);
	return NO_SUCHNAME;
}
Status Insert(Contacts cont)//��̨���ݵĲ���
{
	FILE *fileout = fopen("contacts.dat", "ab");
	if (!fileout)
		return NO_ADDRESSEXIST;
	fwrite(&cont,sizeof(Contacts),1,fileout);
	fclose(fileout);
	return OK;
}

Status Send(SOCKET *client,Contacts cont)//������ϵ����client
{
	send(*client, (char *)&cont, sizeof(cont), 0);
	return OK;
}