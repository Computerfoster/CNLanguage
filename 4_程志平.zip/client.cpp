#include <winsock2.h>
#include <stdio.h>


#include "../server/datagram.h"
#define MAX_DATA_LEN 1024
char destip[20];
struct hostent *hp = NULL;

#pragma  comment(lib,"ws2_32.lib")

int main()
{
	system("color 0a");
	printf("\t\tC/SͨѶ¼�ͻ���\n");
	printf("\t\t������Ĭ�϶˿�:8088\n");
	printf("\t##################################\n");
	
	printf("\t�����������ip��ַ������:");
	scanf("%s",destip);

	WORD sockVersion = MAKEWORD(2, 2);
	WSADATA data;
	if (WSAStartup(sockVersion, &data) != 0)
	{
		return 0;
	}

	SOCKET c_server = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (c_server == INVALID_SOCKET)
	{
		printf("invalid socket !");
		return 0;
	}

	sockaddr_in serAddr;
	if ((hp = gethostbyname(destip)) != NULL)
	{
		memcpy(&(serAddr.sin_addr),hp->h_addr,hp->h_length);
		serAddr.sin_family = hp->h_addrtype;
	}
	else
	{
		printf("��������ȷ�ĵ�ַ!");
		Sleep(1000);
		return 0;
	}

	//serAddr.sin_family = AF_INET;
	serAddr.sin_port = htons(8088);
	//serAddr.sin_addr.S_un.S_addr = inet_addr(destip);
	if (connect(c_server, (sockaddr *)&serAddr, sizeof(serAddr)) == SOCKET_ERROR)
	{
		printf("connect error !");
		closesocket(c_server);
		return 0;
	}

	printf("\t\t1.��ʾ������ϵ����Ϣ\n");
	printf("\t\t2.������ϵ����Ϣ\n");
	printf("\t\t3.�˳�\n");
	printf("\t##################################\n");

	char *sendData;
	char *recData;

	Sleep(1000);
	recData = (char *)malloc(MAX_DATA_LEN);
	sendData = (char *)malloc(MAX_DATA_LEN);
	memset(recData, 0, sizeof(recData));
	int ret = recv(c_server, recData, MAX_DATA_LEN, 0);
	if (ret > 0)
	{
		recData[ret] = 0x00;
		printf(&recData[1]);
	}
	while (1)
	{
		memset(sendData, 0, sizeof(sendData));
 		scanf("%s", sendData);
		send(c_server, sendData, strlen(sendData), 0);
		memset(recData, 0, sizeof(sendData));
		int ret = 0;
		ret = recv(c_server, recData, MAX_DATA_LEN, 0);
		if (ret > 0&&atoi(&recData[0]) == 0)
		{
			recData[ret] = 0x00;
			printf(&recData[1]);
		}
		if (ret > 0 && atoi(&recData[0]) == 1)
		{
			Contacts tmp;
			ret = 0;
			while (ret = recv(c_server, (char *)&tmp, sizeof(Contacts), 0) > 0)
			{
				if (strcmp(tmp.name, ""))
				{
					printf("%s\t%d\t%s\t%s\t%s\t%s\n", tmp.name, tmp.age, tmp.sex?"��":"Ů", tmp.unit, tmp.tel, tmp.ip);
				}
				else
					break;
			}
			memset(recData, 0, MAX_DATA_LEN);
			ret = recv(c_server,recData,MAX_DATA_LEN,0);
			if (ret > 0)
			{
				recData[ret] = 0x00;
				printf(&recData[1]);
			}
		}
		if (ret > 0 && atoi(&recData[0]) == 2)
		{
			int tmp;
			char name[20];
			int age;
			bool sex;
			char unit[30];
			char tel[15];
			int ip;
			printf("��������������,����,�Ա�(��:1;Ů:0),��λ,�绰(�Իس�����)\n");
			scanf("%s", name);
			scanf("%d", &age);
			scanf("%d", &tmp);
			if (tmp == 1)
				sex = 1;
			else
				sex = 0;
			scanf("%s", unit);
			scanf("%s", tel);
			ip = 0;
			Contacts cont;
			memcpy(cont.name, &name, sizeof(name));
			cont.age = age;
			cont.sex = sex;
			memcpy(cont.unit, &unit, sizeof(unit));
			memcpy(cont.tel, &tel, sizeof(tel));
			//#########������########
			printf("%s\t%d\t%s\t%s\t%s\n", cont.name, cont.age, cont.sex ? "��" : "Ů", cont.unit, cont.tel);
			//#######################
			send(c_server, (char *)&cont, sizeof(Contacts), 0);
			printf("#########��Ϣ¼�����########\n");
		}
		if (ret > 0 && atoi(&recData[0]) == 3)
		{
			memset(sendData,0,MAX_DATA_LEN);
			strcpy(sendData,"3\n");
			send(c_server,sendData,sizeof(sendData),0);
			memset(recData, 0, MAX_DATA_LEN);
			recData[recv(c_server, recData, MAX_DATA_LEN, 0)] = 0xff;
			printf("%s",recData);
			break;
		}
		//###����ȷ�Ͻ�����Ϣ###
		memset(sendData, 0, MAX_DATA_LEN);
		strcpy(sendData, "OK\n");
		send(c_server, sendData, strlen(sendData), 0);
		//######################
	}
	closesocket(c_server);
	WSACleanup();

	if (!sendData)
		free(sendData);
	if (!recData)
		free(recData);

	return 0;
}
